create extension if not exists pgcrypto;
create type public.app_role as enum ('admin','clerk','teacher','student');
create type public.application_status as enum ('pending','approved','rejected');

create table if not exists public.profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 role public.app_role not null,
 staff_id text unique,
 full_name text not null,
 active boolean not null default true,
 created_at timestamptz not null default now()
);
create table if not exists public.staff_login_security(
 profile_id uuid primary key references public.profiles(id) on delete cascade,
 failed_attempts integer not null default 0,
 locked_until timestamptz,
 updated_at timestamptz not null default now()
);
create table if not exists public.teacher_applications(
 id uuid primary key default gen_random_uuid(), auth_user_id uuid references auth.users(id) on delete set null,
 full_name text not null, gender text, dob date, photo_url text, mobile text, email text,
 address text, city text, state text, emergency_contact text, username text,
 highest_qualification text, degree_subject text, professional_qualification text,
 university_college text, passing_year int, certifications text, main_subject text,
 additional_subject text, classes_can_teach text[], designation text,
 experience_years numeric, previous_employer text, employment_type text,
 qualification_certificate_url text, experience_certificate_url text,
 id_proof_url text, signature_url text, declaration boolean not null default false,
 status public.application_status not null default 'pending',
 reviewed_by uuid references auth.users(id) on delete set null, reviewed_at timestamptz,
 created_at timestamptz not null default now()
);
create table if not exists public.students(
 id uuid primary key default gen_random_uuid(), auth_user_id uuid unique references auth.users(id) on delete set null,
 admission_no text unique, full_name text not null, class_name text, section text, dob date,
 guardian_name text, guardian_phone text, address text, photo_url text, created_at timestamptz not null default now()
);
create table if not exists public.attendance(
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.students(id) on delete cascade,
 attendance_date date not null, status text not null check(status in ('present','absent','late','leave')),
 marked_by uuid references auth.users(id), unique(student_id,attendance_date)
);
create table if not exists public.fees(
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.students(id) on delete cascade,
 fee_head text not null, amount numeric(12,2) not null, due_date date, paid_amount numeric(12,2) not null default 0
);
create table if not exists public.exams(
 id uuid primary key default gen_random_uuid(), class_name text not null, subject text not null,
 exam_name text not null, exam_date date not null, room text, max_marks int
);
create table if not exists public.notices(
 id uuid primary key default gen_random_uuid(), title text not null, body text not null,
 audience text[] not null default array['public'], published boolean not null default false,
 created_by uuid references auth.users(id), approved_by uuid references auth.users(id),
 created_at timestamptz not null default now(), published_at timestamptz
);
create table if not exists public.enquiries(
 id uuid primary key default gen_random_uuid(), parent_name text not null, mobile text not null,
 email text, class_name text, message text, created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.teacher_applications enable row level security;
alter table public.students enable row level security;
alter table public.attendance enable row level security;
alter table public.fees enable row level security;
alter table public.exams enable row level security;
alter table public.notices enable row level security;
alter table public.enquiries enable row level security;

create or replace function public.is_staff() returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from profiles where id=auth.uid() and role in ('admin','clerk') and active); $$;
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from profiles where id=auth.uid() and role='admin' and active); $$;

create policy "own profile" on public.profiles for select using(id=auth.uid());
create policy "published notices public" on public.notices for select using(published=true);
create policy "staff teacher applications read" on public.teacher_applications for select using(public.is_staff());
create policy "admin teacher applications update" on public.teacher_applications for update using(public.is_admin()) with check(public.is_admin());
create policy "student own row" on public.students for select using(auth_user_id=auth.uid());
create policy "student attendance" on public.attendance for select using(exists(select 1 from students s where s.id=student_id and s.auth_user_id=auth.uid()));
create policy "student fees" on public.fees for select using(exists(select 1 from students s where s.id=student_id and s.auth_user_id=auth.uid()));
create policy "student exams" on public.exams for select using(true);
create policy "staff attendance all" on public.attendance for all using(public.is_staff()) with check(public.is_staff());
create policy "staff fees all" on public.fees for all using(public.is_staff()) with check(public.is_staff());
create policy "staff notices all" on public.notices for all using(public.is_staff()) with check(public.is_staff());
create policy "public enquiry insert" on public.enquiries for insert with check(true);
